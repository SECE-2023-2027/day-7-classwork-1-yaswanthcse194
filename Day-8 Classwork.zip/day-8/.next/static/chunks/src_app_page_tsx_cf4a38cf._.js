(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_9efed580._.js",
  "static/chunks/src_components_Counter_Counter_9c09f466.css"
],
    source: "dynamic"
});
