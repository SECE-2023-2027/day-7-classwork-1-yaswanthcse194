globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/[root-of-the-server]__e2c08166._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_a51498a5._.js",
      "static/chunks/[root-of-the-server]__49fd8634._.js",
      "static/chunks/pages__app_5771e187._.js",
      "static/chunks/pages__app_9114105e._.js"
    ],
    "/_error": [
      "static/chunks/[root-of-the-server]__8df7605f._.js",
      "static/chunks/node_modules_react-dom_82bb97c6._.js",
      "static/chunks/node_modules_a51498a5._.js",
      "static/chunks/[root-of-the-server]__923cb372._.js",
      "static/chunks/pages__error_5771e187._.js",
      "static/chunks/pages__error_ec6747c0._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_17e42fcf._.js",
    "static/chunks/node_modules_next_dist_compiled_2ce9398a._.js",
    "static/chunks/node_modules_next_dist_client_8f19e6fb._.js",
    "static/chunks/node_modules_next_dist_0eb1e458._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_00636ac3._.js",
    "static/chunks/_e69f0d32._.js",
    "static/chunks/_a894171a._.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];